# Edición IA local

Esta versión no utiliza OpenAI, API keys ni servicios externos para editar imágenes.

## Funciones locales
- OCR con Google ML Kit en el dispositivo.
- Cambios básicos por lenguaje natural: resultado, rival, fecha y hora cuando el texto se puede localizar.
- Blanco y negro.
- Efecto local de color para conservar colores fuertes.
- Deshacer.
- Navegación atrás desde el editor.
- Guardar y compartir PNG.
- Mejora de resolución local x2.

La edición local es determinista y no tiene las capacidades generativas de un modelo remoto. Está pensada para los flyers de La Fábrica y evita cobros de API.
