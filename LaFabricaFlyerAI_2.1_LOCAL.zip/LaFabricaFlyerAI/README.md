# La Fábrica Flyer AI 2.1 Local

Editor de flyers de La Fábrica pensado para Android y compilación con GitHub Actions.

## Esta versión
- No necesita OPENAI_API_KEY.
- No usa internet para editar.
- OCR local con ML Kit.
- Editor con instrucciones sencillas.
- Deshacer y botón de volver.
- Diseño adaptable para pantallas pequeñas.
- Icono de aplicación incluido.

### Ejemplos
- `resultado 2-1`
- `cambia el rival a Santos FC`
- `fecha 30/08/26`
- `hora 7:30 PM`
- `fondo blanco y negro`
- `jugador a color`

Puedes combinar instrucciones. Los reemplazos de texto dependen de que el OCR encuentre la línea correspondiente.
