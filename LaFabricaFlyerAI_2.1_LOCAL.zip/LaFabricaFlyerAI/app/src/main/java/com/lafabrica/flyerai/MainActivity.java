package com.lafabrica.flyerai;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.net.Uri;
import android.provider.MediaStore;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;

import java.io.*;
import java.util.*;
import java.util.regex.*;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import com.google.mlkit.vision.text.Text;

public class MainActivity extends Activity {
    LinearLayout root, content;
    ImageView preview;
    Bitmap current;
    TextView status, detectedText;
    EditText command;
    Uri playerUri;
    ArrayList<String> detectedLines = new ArrayList<>();
    ArrayDeque<Bitmap> undoStack = new ArrayDeque<>();

    int white = Color.WHITE, gray = Color.rgb(170,170,170), panel = Color.rgb(22,22,22);

    int dp(float v) {
        return (int)(v * getResources().getDisplayMetrics().density + .5f);
    }

    TextView tv(String s, int sp) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextColor(white);
        t.setTextSize(sp);
        t.setPadding(dp(4), dp(3), dp(4), dp(3));
        return t;
    }

    Button btn(String s) {
        Button b = new Button(this);
        b.setText(s);
        b.setTextColor(Color.BLACK);
        b.setTextSize(13);
        b.setAllCaps(false);
        b.setMinHeight(dp(44));
        b.setBackgroundColor(white);
        b.setPadding(dp(8), 0, dp(8), 0);
        return b;
    }

    Button darkBtn(String s) {
        Button b = new Button(this);
        b.setText(s);
        b.setTextColor(white);
        b.setTextSize(13);
        b.setAllCaps(false);
        b.setMinHeight(dp(44));
        GradientDrawable g = new GradientDrawable();
        g.setColor(Color.rgb(38,38,38));
        g.setCornerRadius(dp(10));
        b.setBackground(g);
        return b;
    }

    LinearLayout card() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(14), dp(12), dp(14), dp(12));
        GradientDrawable g = new GradientDrawable();
        g.setColor(panel);
        g.setCornerRadius(dp(18));
        l.setBackground(g);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(dp(10), dp(6), dp(10), dp(6));
        l.setLayoutParams(p);
        return l;
    }

    @Override
    public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        buildHome();
    }

    void base(boolean back) {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(8,8,8));

        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(10), dp(7), dp(12), dp(5));

        if (back) {
            TextView arrow = tv("‹", 40);
            arrow.setGravity(Gravity.CENTER);
            arrow.setContentDescription("Volver");
            arrow.setOnClickListener(v -> buildHome());
            bar.addView(arrow, new LinearLayout.LayoutParams(dp(46), dp(54)));
        }

        ImageView logo = new ImageView(this);
        try {
            logo.setImageBitmap(BitmapFactory.decodeStream(getAssets().open("logo_lf.png")));
        } catch (Exception ignored) {}
        logo.setAdjustViewBounds(true);
        bar.addView(logo, new LinearLayout.LayoutParams(dp(48), dp(48)));

        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        titles.addView(tv("LA FÁBRICA", 18));
        titles.addView(tv("FLYER AI • LOCAL", 10));
        bar.addView(titles, new LinearLayout.LayoutParams(0, -2, 1));

        TextView menu = tv("⋮", 28);
        menu.setGravity(Gravity.CENTER);
        menu.setContentDescription("Menú");
        bar.addView(menu, new LinearLayout.LayoutParams(dp(34), dp(54)));

        root.addView(bar);

        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(0, dp(2), 0, dp(18));

        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        sv.setClipToPadding(false);
        sv.addView(content);
        root.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1));

        setContentView(root);
    }

    void buildHome() {
        base(false);

        LinearLayout hero = card();
        TextView h = tv("CREA FLYERS\nCOMO UN PRO", 25);
        h.setTypeface(null, Typeface.BOLD);
        hero.addView(h);
        hero.addView(tv("EDITOR LOCAL • SIN API • SIN PAGOS EXTRA\nHECHOS PARA COMPETIR", 12));

        Button n = btn("＋  NUEVO FLYER");
        hero.addView(n, new LinearLayout.LayoutParams(-1, dp(48)));
        n.setOnClickListener(v -> pickFlyer());
        content.addView(hero);

        LinearLayout ai = card();
        ai.addView(tv("EDICIÓN INTELIGENTE LOCAL", 17));
        ai.addView(tv(
            "Escribe cambios sencillos como: “resultado 2-1”, “cambia el rival a Santos FC”, " +
            "“fondo blanco y negro” o “deja el jugador a color”. Todo se procesa en el teléfono.",
            12));
        Button x = btn("Abrir editor");
        ai.addView(x, new LinearLayout.LayoutParams(-1, dp(46)));
        x.setOnClickListener(v -> pickFlyer());
        content.addView(ai);

        TextView ph = tv("PLANTILLAS", 16);
        ph.setPadding(dp(14), dp(12), dp(14), 0);
        content.addView(ph);

        String[] names = {"CONVOCATORIA", "RESULTADO", "MVP", "PRÓXIMO PARTIDO"};
        for (String s : names) {
            LinearLayout c = card();
            c.addView(tv(s, 16));
            c.addView(tv("Plantilla inteligente de La Fábrica", 11));
            Button q = btn("Usar plantilla");
            c.addView(q, new LinearLayout.LayoutParams(-1, dp(42)));
            q.setOnClickListener(v -> pickFlyer());
            content.addView(c);
        }

        LinearLayout note = card();
        note.addView(tv("100% LOCAL", 14));
        note.addView(tv(
            "No se solicita OPENAI_API_KEY. Se eliminó la conexión de IA externa. " +
            "El OCR usa ML Kit en el dispositivo y los cambios básicos se aplican localmente.",
            11));
        content.addView(note);
    }

    void pickFlyer() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.setType("image/*");
        i.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(i, 10);
    }

    @Override
    protected void onActivityResult(int r, int c, Intent d) {
        super.onActivityResult(r, c, d);
        if (c != RESULT_OK || d == null) return;
        try {
            if (r == 10) {
                current = MediaStore.Images.Media.getBitmap(getContentResolver(), d.getData());
                undoStack.clear();
                openEditor();
            } else if (r == 11) {
                playerUri = d.getData();
                if (status != null) status.setText("Foto del jugador cargada ✓");
            }
        } catch (Exception e) {
            Toast.makeText(this, "No se pudo cargar la imagen", Toast.LENGTH_SHORT).show();
        }
    }

    EditText field(String hint, String val) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setHintTextColor(gray);
        e.setTextColor(white);
        e.setText(val);
        e.setTextSize(14);
        e.setSingleLine(false);
        e.setPadding(dp(8), dp(6), dp(8), dp(6));
        GradientDrawable g = new GradientDrawable();
        g.setColor(Color.rgb(30,30,30));
        g.setCornerRadius(dp(10));
        e.setBackground(g);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(52));
        p.setMargins(0, dp(5), 0, dp(5));
        e.setLayoutParams(p);
        return e;
    }

    void openEditor() {
        base(true);
        content.addView(tv("EDITOR LOCAL", 22));
        content.addView(tv("Sin internet • sin API • con deshacer", 11));

        LinearLayout pc = card();
        preview = new ImageView(this);
        preview.setAdjustViewBounds(true);
        preview.setScaleType(ImageView.ScaleType.FIT_CENTER);
        preview.setMaxHeight(dp(330));
        preview.setImageBitmap(current);
        pc.addView(preview, new LinearLayout.LayoutParams(-1, -2));
        content.addView(pc);

        LinearLayout actions = card();
        Button undo = darkBtn("↶  DESHACER");
        actions.addView(undo, new LinearLayout.LayoutParams(-1, dp(44)));
        undo.setOnClickListener(v -> undo());
        Button redoInfo = darkBtn("↻  Repetir último cambio");
        actions.addView(redoInfo, new LinearLayout.LayoutParams(-1, dp(44)));
        redoInfo.setOnClickListener(v -> {
            if (command != null && command.getText().length() > 0) aiEdit();
            else status.setText("Escribe primero un cambio.");
        });
        content.addView(actions);

        LinearLayout ai = card();
        ai.addView(tv("DILE QUÉ HACER", 17));
        ai.addView(tv(
            "Ejemplos: “resultado 2-1”; “cambia el rival a Santos FC”; " +
            "“fecha 30/08/26”; “hora 7:30 PM”; “fondo blanco y negro”; " +
            "“jugador a color”. Puedes combinar varios.",
            12));

        command = field(
            "Ej.: resultado 2-1, rival Santos FC, fondo blanco y negro",
            "");
        command.setMinHeight(dp(105));
        ai.addView(command, new LinearLayout.LayoutParams(-1, dp(112)));

        Button run = btn("✦  APLICAR CAMBIOS");
        ai.addView(run, new LinearLayout.LayoutParams(-1, dp(50)));
        run.setOnClickListener(v -> aiEdit());

        Button add = darkBtn("＋  AÑADIR / CAMBIAR FOTO DEL JUGADOR");
        ai.addView(add, new LinearLayout.LayoutParams(-1, dp(44)));
        add.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.setType("image/*");
            i.addCategory(Intent.CATEGORY_OPENABLE);
            startActivityForResult(i, 11);
        });

        status = tv("Listo. Escribe una instrucción y toca APLICAR CAMBIOS.", 11);
        status.setTextColor(gray);
        ai.addView(status);
        content.addView(ai);

        LinearLayout ocr = card();
        ocr.addView(tv("LECTURA RÁPIDA", 15));
        Button an = btn("Analizar texto del flyer");
        ocr.addView(an, new LinearLayout.LayoutParams(-1, dp(44)));
        an.setOnClickListener(v -> analyzeFlyer());
        detectedText = tv("OCR local disponible.", 11);
        detectedText.setTextColor(gray);
        ocr.addView(detectedText);
        content.addView(ocr);

        Button hd = darkBtn("✦  MEJORAR CALIDAD HD (LOCAL)");
        content.addView(hd, new LinearLayout.LayoutParams(-1, dp(48)));
        hd.setOnClickListener(v -> {
            saveUndo();
            current = upscale(current, 2);
            preview.setImageBitmap(current);
            status.setText("Resolución aumentada x2 ✓");
        });

        Button save = btn("GUARDAR / COMPARTIR");
        content.addView(save, new LinearLayout.LayoutParams(-1, dp(50)));
        save.setOnClickListener(v -> exportFlyer());
    }

    void saveUndo() {
        if (current == null) return;
        if (undoStack.size() >= 5) undoStack.removeFirst();
        undoStack.addLast(current.copy(current.getConfig() != null ? current.getConfig() : Bitmap.Config.ARGB_8888, true));
    }

    void undo() {
        if (undoStack.isEmpty()) {
            if (status != null) status.setText("No hay cambios para deshacer.");
            return;
        }
        current = undoStack.removeLast();
        if (preview != null) preview.setImageBitmap(current);
        if (status != null) status.setText("Cambio deshecho ✓");
    }

    void analyzeFlyer() {
        if (current == null) return;
        status.setText("Analizando… OCR local");
        InputImage image = InputImage.fromBitmap(current, 0);
        TextRecognizer r = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        r.process(image)
            .addOnSuccessListener(t -> {
                detectedLines.clear();
                for (Text.TextBlock b : t.getTextBlocks())
                    for (Text.Line l : b.getLines())
                        if (!l.getText().trim().isEmpty()) detectedLines.add(l.getText().trim());

                StringBuilder s = new StringBuilder();
                for (String line : detectedLines) {
                    if (s.length() > 0) s.append('\n');
                    s.append("• ").append(line);
                }
                detectedText.setText(s.length() > 0 ? s.toString() : "No se encontró texto.");
                status.setText("OCR listo ✓ " + detectedLines.size() + " líneas");
                r.close();
            })
            .addOnFailureListener(e -> {
                status.setText("OCR no disponible");
                r.close();
            });
    }

    void aiEdit() {
        if (current == null || command == null) return;
        String cmd = command.getText().toString().trim();
        if (cmd.isEmpty()) {
            Toast.makeText(this, "Escribe qué quieres cambiar", Toast.LENGTH_SHORT).show();
            return;
        }

        hideKeyboard();
        status.setText("Aplicando cambios localmente…");

        // OCR is used first so text replacements can use real bounding boxes.
        InputImage image = InputImage.fromBitmap(current, 0);
        TextRecognizer r = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        r.process(image)
            .addOnSuccessListener(t -> {
                saveUndo();
                Bitmap result = current.copy(Bitmap.Config.ARGB_8888, true);

                if (hasAny(cmd, "blanco y negro", "blanco y negro", "b/n", "bn", "escala de grises"))
                    result = grayscale(result);

                if (hasAny(cmd, "jugador a color", "jugador déjale el color", "jugador dejale el color",
                           "deja el jugador a color", "dejar el jugador a color"))
                    result = colorPop(result);

                result = applyTextCommands(result, t, cmd);

                current = result;
                preview.setImageBitmap(current);
                status.setText("¡Listo! Cambios locales aplicados ✓");
                r.close();
            })
            .addOnFailureListener(e -> {
                // Even if OCR fails, image-only effects still work.
                saveUndo();
                Bitmap result = current.copy(Bitmap.Config.ARGB_8888, true);
                if (hasAny(cmd, "blanco y negro", "b/n", "bn", "escala de grises"))
                    result = grayscale(result);
                if (hasAny(cmd, "jugador a color", "jugador déjale el color", "jugador dejale el color",
                           "deja el jugador a color", "dejar el jugador a color"))
                    result = colorPop(result);
                current = result;
                preview.setImageBitmap(current);
                status.setText("Cambios de imagen aplicados ✓ (OCR no disponible)");
            });
    }

    Bitmap applyTextCommands(Bitmap source, Text result, String cmd) {
        Bitmap out = source.copy(Bitmap.Config.ARGB_8888, true);
        Canvas canvas = new Canvas(out);

        String score = parseScore(cmd);
        if (score != null) {
            Text.Line target = findScoreLine(result);
            if (target != null) drawReplacement(canvas, source, target.getBoundingBox(), score, true);
        }

        String rival = parseRival(cmd);
        if (rival != null) {
            Text.Line target = findRivalLine(result);
            if (target != null) drawReplacement(canvas, source, target.getBoundingBox(), rival, false);
        }

        String date = parseDate(cmd);
        if (date != null) {
            Text.Line target = findDateLine(result);
            if (target != null) drawReplacement(canvas, source, target.getBoundingBox(), date, false);
        }

        String time = parseTime(cmd);
        if (time != null) {
            Text.Line target = findTimeLine(result);
            if (target != null) drawReplacement(canvas, source, target.getBoundingBox(), time, false);
        }

        return out;
    }

    boolean hasAny(String s, String... terms) {
        String x = normalize(s);
        for (String term : terms) if (x.contains(normalize(term))) return true;
        return false;
    }

    String normalize(String s) {
        return s.toLowerCase(Locale.ROOT)
                .replace("á","a").replace("é","e").replace("í","i")
                .replace("ó","o").replace("ú","u").replace("ñ","n");
    }

    String parseScore(String cmd) {
        Matcher m = Pattern.compile("(?i)(?:resultado|marcador|score)\\s*[:=]?\\s*(\\d{1,2})\\s*[-:]\\s*(\\d{1,2})").matcher(cmd);
        if (m.find()) return m.group(1) + " - " + m.group(2);
        m = Pattern.compile("\\b(\\d{1,2})\\s*[-:]\\s*(\\d{1,2})\\b").matcher(cmd);
        return m.find() ? m.group(1) + " - " + m.group(2) : null;
    }

    String parseRival(String cmd) {
        Pattern[] ps = {
            Pattern.compile("(?i)(?:rival|otro equipo|equipo rival|contrario)\\s*(?:a|:|=|que|por)?\\s*([A-Za-zÁÉÍÓÚÑáéíóúñ0-9 .&_-]{2,40})"),
            Pattern.compile("(?i)cambia(?:\\s+el)?\\s+(?:equipo|rival)\\s+(?:a|por)\\s+([A-Za-zÁÉÍÓÚÑáéíóúñ0-9 .&_-]{2,40})")
        };
        for (Pattern p : ps) {
            Matcher m = p.matcher(cmd);
            if (m.find()) return cleanTeam(m.group(1));
        }
        return null;
    }

    String cleanTeam(String s) {
        s = s.trim();
        s = s.replaceAll("(?i)\\s+(?:y|con|resultado|fecha|hora|fondo|jugador)\\b.*$", "");
        return s.trim();
    }

    String parseDate(String cmd) {
        Matcher m = Pattern.compile("(?i)(?:fecha\\s*(?:a|:|=)?\\s*)?(\\d{1,2}[/-]\\d{1,2}[/-]\\d{2,4})").matcher(cmd);
        return m.find() ? m.group(1).replace('-', '/') : null;
    }

    String parseTime(String cmd) {
        Matcher m = Pattern.compile("(?i)(?:hora\\s*(?:a|:|=)?\\s*)?(\\d{1,2}:\\d{2}\\s*(?:am|pm)?)").matcher(cmd);
        return m.find() ? m.group(1) : null;
    }

    Text.Line findScoreLine(Text result) {
        for (Text.TextBlock b : result.getTextBlocks())
            for (Text.Line l : b.getLines()) {
                String s = l.getText();
                if (s.matches(".*\\b\\d{1,2}\\s*[-:]\\s*\\d{1,2}\\b.*")) return l;
            }
        return null;
    }

    Text.Line findRivalLine(Text result) {
        Text.Line best = null;
        for (Text.TextBlock b : result.getTextBlocks())
            for (Text.Line l : b.getLines()) {
                String s = normalize(l.getText());
                if (s.contains("fc") || s.contains("club") || s.contains("f.c")) best = l;
            }
        return best;
    }

    Text.Line findDateLine(Text result) {
        for (Text.TextBlock b : result.getTextBlocks())
            for (Text.Line l : b.getLines())
                if (l.getText().matches(".*\\d{1,2}[/-]\\d{1,2}[/-]\\d{2,4}.*")) return l;
        return null;
    }

    Text.Line findTimeLine(Text result) {
        for (Text.TextBlock b : result.getTextBlocks())
            for (Text.Line l : b.getLines())
                if (l.getText().matches(".*\\d{1,2}:\\d{2}.*")) return l;
        return null;
    }

    void drawReplacement(Canvas canvas, Bitmap source, Rect box, String text, boolean big) {
        if (box == null || text == null || text.isEmpty()) return;

        int pad = Math.max(3, dp(2));
        int left = Math.max(0, box.left - pad);
        int top = Math.max(0, box.top - pad);
        int right = Math.min(source.getWidth(), box.right + pad);
        int bottom = Math.min(source.getHeight(), box.bottom + pad);

        int bg = sampleBackground(source, box);
        Paint cover = new Paint(Paint.ANTI_ALIAS_FLAG);
        cover.setColor(bg);
        canvas.drawRect(left, top, right, bottom, cover);

        float size = Math.max(12f, Math.min(box.height() * (big ? 0.95f : 0.82f), 96f));
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(contrastColor(bg));
        p.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        p.setTextSize(size);
        p.setTextAlign(Paint.Align.CENTER);

        Paint.FontMetrics fm = p.getFontMetrics();
        float y = (top + bottom) / 2f - (fm.ascent + fm.descent) / 2f;
        canvas.drawText(text, (left + right) / 2f, y, p);
    }

    int sampleBackground(Bitmap b, Rect box) {
        int[] pts = new int[] {
            Math.max(0, box.left - 4), Math.max(0, box.top - 4),
            Math.min(b.getWidth()-1, box.right + 4), Math.max(0, box.top - 4),
            Math.max(0, box.left - 4), Math.min(b.getHeight()-1, box.bottom + 4),
            Math.min(b.getWidth()-1, box.right + 4), Math.min(b.getHeight()-1, box.bottom + 4)
        };
        long r=0,g=0,bl=0; int n=0;
        for (int i=0;i<pts.length;i+=2) {
            int c=b.getPixel(pts[i],pts[i+1]);
            r+=Color.red(c); g+=Color.green(c); bl+=Color.blue(c); n++;
        }
        return Color.rgb((int)(r/n),(int)(g/n),(int)(bl/n));
    }

    int contrastColor(int bg) {
        int lum = (299*Color.red(bg)+587*Color.green(bg)+114*Color.blue(bg))/1000;
        return lum > 145 ? Color.BLACK : Color.WHITE;
    }

    Bitmap grayscale(Bitmap b) {
        Bitmap out = Bitmap.createBitmap(b.getWidth(), b.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(out);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        ColorMatrix m = new ColorMatrix();
        m.setSaturation(0f);
        p.setColorFilter(new android.graphics.ColorMatrixColorFilter(m));
        c.drawBitmap(b, 0, 0, p);
        return out;
    }

    // Local "color pop": preserves strongly saturated pixels while desaturating low-saturation areas.
    // It is intentionally local and deterministic; it does not claim to segment a player perfectly.
    Bitmap colorPop(Bitmap b) {
        Bitmap out = b.copy(Bitmap.Config.ARGB_8888, true);
        int w=b.getWidth(), h=b.getHeight();
        int[] px=new int[w*h];
        b.getPixels(px,0,w,0,0,w,h);
        for(int i=0;i<px.length;i++){
            int c=px[i];
            float[] hsv=new float[3];
            Color.colorToHSV(c,hsv);
            if(hsv[1] < 0.32f){
                int g=(int)(0.299f*Color.red(c)+0.587f*Color.green(c)+0.114f*Color.blue(c));
                px[i]=Color.rgb(g,g,g);
            } else {
                hsv[1]=Math.min(1f,hsv[1]*1.08f);
                px[i]=Color.HSVToColor(Color.alpha(c),hsv);
            }
        }
        out.setPixels(px,0,w,0,0,w,h);
        return out;
    }

    File bitmapFile(Bitmap b) throws Exception {
        File f = new File(getCacheDir(), "flyer_input.png");
        FileOutputStream o = new FileOutputStream(f);
        b.compress(Bitmap.CompressFormat.PNG, 100, o);
        o.close();
        return f;
    }

    Bitmap upscale(Bitmap b, int scale) {
        int w = Math.min(b.getWidth()*scale, 4096);
        int h = Math.min(b.getHeight()*scale, 4096);
        return Bitmap.createScaledBitmap(b, w, h, true);
    }

    void exportFlyer() {
        if (current == null) return;
        try {
            String fn = "LaFabrica_Flyer_" + System.currentTimeMillis() + ".png";
            ContentValues v = new ContentValues();
            v.put(MediaStore.Images.Media.DISPLAY_NAME, fn);
            v.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
            v.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/La Fabrica Flyer AI");
            Uri u = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v);
            OutputStream os = getContentResolver().openOutputStream(u);
            current.compress(Bitmap.CompressFormat.PNG, 100, os);
            os.close();

            Intent sh = new Intent(Intent.ACTION_SEND);
            sh.setType("image/png");
            sh.putExtra(Intent.EXTRA_STREAM, u);
            startActivity(Intent.createChooser(sh, "Compartir flyer"));
        } catch (Exception e) {
            Toast.makeText(this, "No se pudo guardar", Toast.LENGTH_LONG).show();
        }
    }

    void hideKeyboard() {
        View v = getCurrentFocus();
        if (v != null) {
            InputMethodManager imm = (InputMethodManager)getSystemService(INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
            v.clearFocus();
        }
    }

    @Override
    public void onBackPressed() {
        if (content != null && preview != null) {
            buildHome();
        } else {
            super.onBackPressed();
        }
    }
}
