# Compilar sin Android Studio

La forma más sencilla es usar GitHub Actions. No necesitas instalar Android Studio ni Gradle en el celular.

1. Crea una cuenta en GitHub si no tienes una.
2. Crea un repositorio nuevo, por ejemplo `LaFabricaFlyerAI`.
3. Sube todo el contenido de la carpeta `LaFabricaFlyerAI` del ZIP (incluyendo `.github/workflows/build-apk.yml`).
4. En GitHub abre **Actions** → **Build APK** → **Run workflow**.
5. Espera a que termine el trabajo.
6. En la ejecución terminada, baja el artefacto `LaFabricaFlyerAI-debug`.
7. Dentro estará `app-debug.apk`; pásalo a tu Samsung y toca el APK para instalarlo.

Si Android muestra un aviso de seguridad al instalar una app fuera de Play Store, tendrás que permitir temporalmente la instalación desde esa fuente en los ajustes de Android.
