# La Fábrica Flyer AI 2.0

Editor Android enfocado en flyers de La Fábrica. Carga una imagen y escribe instrucciones naturales para que la IA intente editarla.

## Ejemplos

`cambia la fecha a 30/08/26`

`pon el resultado 3-2 y cambia el rival a Rincón FC`

`pon el fondo totalmente borroso pero deja al jugador principal a color y nítido`

`hazlo más profesional, conserva el logo LF y no cambies el diseño`

## Importante

La app necesita una API key propia de OpenAI. No incluyas una clave real en GitHub. Para uso personal la app permite pegarla en Ajustes del editor y guardarla en el teléfono. Para distribución pública se recomienda un backend seguro.

Compilación sin Android Studio: usa el workflow de GitHub Actions incluido.
