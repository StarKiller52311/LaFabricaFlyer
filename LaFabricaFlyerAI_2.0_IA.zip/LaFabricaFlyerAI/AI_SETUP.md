# La Fábrica Flyer AI 2.0 — edición con IA

Esta versión permite cargar un flyer y escribir instrucciones normales, por ejemplo:

- `Cambia el resultado a 3-2 y la fecha a 30/08/26.`
- `Cambia la foto del jugador y conserva el uniforme.`
- `Pon el fondo totalmente borroso, pero deja al jugador principal a color y nítido.`
- `Haz el fondo en blanco y negro y deja al jugador a color.`
- `Quita el MVP actual y pon a Sebastián Martínez.`

La app envía el flyer a la API de imágenes de OpenAI para realizar la edición. La API también permite analizar imágenes y usar instrucciones multimodales. Ver documentación oficial: https://platform.openai.com/docs/quickstart/make-your-first-api-request

## API key

La aplicación solicita tu propia `OPENAI_API_KEY` y la guarda localmente en preferencias del teléfono. **No viene ninguna clave dentro del proyecto.**

Para uso personal esto es sencillo, pero para publicar la app para otras personas conviene poner un backend/proxy y guardar allí la clave. Nunca subas una API key real a GitHub.

## Compilar sin Android Studio

El workflow `.github/workflows/build-apk.yml` compila el APK en GitHub Actions.

1. Crea un repositorio nuevo en GitHub.
2. Sube todo el contenido de esta carpeta.
3. Abre `Actions`.
4. Ejecuta `Build APK`.
5. Descarga el artefacto `LaFabricaFlyerAI-debug`.
6. Dentro estará `app-debug.apk`.

La edición con IA consume créditos de la API de OpenAI. La tarifa depende del modelo y calidad elegidos; consulta el pricing oficial antes de usarlo mucho.
